﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
     public class commercial
    {
        public int Commercial_numero { get; set; }
        public string Commercial_nom { get; set; }
        public string Commercial_prenom { get; set; }
        
    }
}
