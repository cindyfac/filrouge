﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    public class adresseclient
    {
        public int adresse_id { get; set; }
        public string adresse_pays { get; set; }
        public string adresse_rue { get; set; }
        public string adresse_ville { get; set; }
        public int adresse_codepostal { get; set; }
        public string adresse_mail { get; set; }
        public string adresse_telephone { get; set; }

    }
}
