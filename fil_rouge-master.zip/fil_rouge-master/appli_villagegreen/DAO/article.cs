﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAO
{
    class article
    {
        public int reference {get; set; }
        public string libelle1 { get; set; }
        public string libelle2 { get; set; }
        public string photo { get; set; }
        public int actif { get; set; }
        public int prixht { get; set; }
        public int rubrique { get; set; }
    }
}
