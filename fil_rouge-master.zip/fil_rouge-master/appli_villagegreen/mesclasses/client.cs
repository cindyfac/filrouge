﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Client
{
    public class Class1
    {
        public int id { get; set; }
        public string nom { get; set; }
        public string prenom { get; set; }
        public bool categorie { get; set; }
        public int coefficient { get; set; }
        
    }
}
