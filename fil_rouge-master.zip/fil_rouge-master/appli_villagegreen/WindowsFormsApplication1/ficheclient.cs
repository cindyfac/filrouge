﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using DAO;

namespace WindowsFormsApplication1
{
    public partial class Form_client : Form
    {
        //mes variables
        int moncas = 0;
        int marecherche = 0;


        public void initialisationclient()
        {
            //le groupe box devient modifiable
            gpbx_coordonnees.Enabled = true;
            lbl_reference.Visible = false;
            tb_reference.Visible = false;
            tb_adresse.Clear();
            tb_codepostal.Clear();
            tb_coefficient.Clear();
            tb_mail.Clear();
            tb_nom.Clear();
            tb_prenom.Clear();
            tb_reference.Clear();
            tb_siret.Clear();
            tb_telephone.Clear();
            tb_ville.Clear();
            rb_particulier.Checked = false;
            rb_professionnel.Checked = false;
            lb_commande.Visible = false;
            lbl_commandes.Visible = false;
            btn_valider.Visible = true;
           
           
        }
        public Form_client()
        {
            InitializeComponent();
        }
              
       clientDAO maconnexion = new clientDAO("server =.; database = filrouge; integrated security = true");
       adresseDAO maconnexion2 = new adresseDAO("server =.; database = filrouge; integrated security = true");
       commandeDAO maconnexion3= new commandeDAO("server =.; database = filrouge; integrated security = true");
       commercialDAO maconnexion4 = new commercialDAO("server =. ; database = filrouge; integrated security = true");

        private void Form_client_Load(object sender, EventArgs e)
        {
            //displaymember et valuemember à mettre AVANT le datasource
            lb_client.DisplayMember = "Client_nom";//valeur affichée dans la listBox
            lb_client.ValueMember = "Client_numero";//valeur réelle dans la listBox           
            //fonction pour afficher une liste
            lb_client.DataSource = maconnexion.List();
            lb_client.SelectedIndex = 0; //la selection est sur le premier de la liste

            //---------------------------------------------------------------------
            //affichage dans les tb de recherches
            cb_recherchenom.DisplayMember = "Client_nom";
            cb_recherchenumero.DisplayMember = "Client_numero";
            cb_recherchenom.ValueMember = "Client_numero";
            cb_recherchenumero.ValueMember = "Client_numero";
            cb_recherchenom.DataSource = maconnexion.List();
            cb_recherchenumero.DataSource = maconnexion.List();
            

        }

        private void lb_client_SelectedIndexChanged(object sender, EventArgs e)
        {
            string afficheListe;

             //----------------------------------------------------
          //affichage ds le combobox commercial
            cb_commercial.DisplayMember = "Commercial_nom";//valeur affichée dans la listBox
            cb_commercial.ValueMember = "Commercial_numero";//valeur réelle dans la listBox              
            cb_commercial.DataSource = maconnexion4.List();//fonction pour afficher une liste
            cb_commercial.SelectedIndex = 0; //la selection est sur le premier de la liste
           

            //instanciation des variables adresses et clients
            Client marecherche = new Client();
            adresseclient monadresse = new adresseclient();
            List <Commande> macommande = new List<Commande>();//liste de type commande
            commercial moncommercial = new commercial();
           
            //--------------------------------------------------------------------
           //appel de la fonction find
            marecherche = maconnexion.findclient((int)lb_client.SelectedValue);
            monadresse = maconnexion2.findadresse(marecherche.Adresse_reference);
            macommande = maconnexion3.List((int)lb_client.SelectedValue);          
            moncommercial = maconnexion4.findcommercial((int)lb_client.SelectedValue);

            //---------------------------------------------------------------------          
            //affichage dans le formulaire
            tb_nom.Text = marecherche.Client_numero.ToString();
            tb_adresse.Text = marecherche.Client_nom;
            tb_prenom.Text = marecherche.Client_prenom;
            tb_siret.Text = marecherche.Client_siret.ToString();
            tb_coefficient.Text = marecherche.Client_coefficient.ToString();
            tb_mail.Text = monadresse.adresse_rue;
            tb_codepostal.Text = monadresse.adresse_codepostal.ToString();
            tb_ville.Text = monadresse.adresse_ville;
            tb_telephone.Text = monadresse.adresse_telephone.ToString();
            tb_telephone.Text = monadresse.adresse_mail;           
            cb_commercial.SelectedValue = marecherche.Commercial_numero;
            tb_reference.Text = marecherche.Client_numero.ToString();
            
            //---------------------------------------------
            //affichage dans la listebox commandes
            lb_commande.Items.Clear();//on nettoie la listebox lb_commande

            foreach (Commande cmd in macommande)
            {
                afficheListe = "Ref : " + cmd.Commande_reference.ToString() + " Date : " + cmd.Commande_date + " Total : " + cmd.Commande_totalTTC + "€";
                lb_commande.Items.Add(afficheListe);
            }    
            //----------------------------------------------------
            //cochage des radiobtn
            if(marecherche.Client_categorie)
            {
                rb_particulier.Checked = true;
                Console.WriteLine("particulier");
            }
            else
            {
                rb_professionnel.Checked = true;
                Console.WriteLine("professionnel");
            }
          


        }   
        private void button5_Click(object sender, EventArgs e)
        {
            Close();
        }
        private void btn_ajouter_Click(object sender, EventArgs e)
        {
            //appel de la fonction d'initialisation
            initialisationclient();
            moncas = 1;          
       }

        private void btn_valider_Click(object sender, EventArgs e)
        {
            adresseclient nouvelleadresse = new adresseclient();
            nouvelleadresse.adresse_rue = tb_mail.Text;
            nouvelleadresse.adresse_codepostal = Convert.ToInt32(tb_codepostal.Text);
            nouvelleadresse.adresse_ville = tb_ville.Text;
            nouvelleadresse.adresse_mail = tb_mail.Text;
            nouvelleadresse.adresse_telephone = tb_telephone.Text;
           

            //création d'un nouveau client 
            Client nouveauclient = new Client();
            //creation d'une nouvelle adresse
            
           if(rb_particulier.Checked)
            {
                nouveauclient.Client_categorie = true;
            }
           if(rb_professionnel.Checked)
            {
                nouveauclient.Client_categorie = false;
            }
           
            if (nouveauclient.Client_categorie)
            {

                nouveauclient.Client_nom = tb_adresse.Text;
                nouveauclient.Client_prenom = tb_prenom.Text;
                       
           }
            else
            {
                nouveauclient.Client_nom = tb_adresse.Text;
                nouveauclient.Client_prenom = tb_prenom.Text;
                nouveauclient.Client_siret = Convert.ToInt32(tb_siret.Text);
            }
            nouveauclient.Commercial_numero = (int)cb_commercial.SelectedValue;
            maconnexion.insertclient(nouveauclient);
            maconnexion2.insertadresse(nouvelleadresse);
        }

        private void rb_particulier_CheckedChanged(object sender, EventArgs e)
        {
            if (rb_particulier.Checked)
            {
                tb_siret.Enabled = false;
                tb_siret.Clear();
            }
            else
            {
                tb_siret.Enabled = true;
            }
        }
               
        private void btn_recherchenom_Click(object sender, EventArgs e)
        {
            cb_recherchenom.Enabled = true;
            btn_rechercher.Enabled = true;
            cb_recherchenumero.Enabled = false;
            marecherche = 1;
        }

        private void btn_recherchenumero_Click(object sender, EventArgs e)
        {
            cb_recherchenumero.Enabled = true;
            btn_rechercher.Enabled = true;
            cb_recherchenom.Enabled = false;
            marecherche = 2;
        }

        private void btn_rechercher_Click(object sender, EventArgs e)
        {
            switch (marecherche)
            {
                case  1:
                    Client monclient = new Client();
                    lb_client.SelectedIndex = cb_recherchenom.SelectedIndex;
                    break;

                case  2:
                    Console.WriteLine("cas2");
                    lb_client.SelectedIndex = cb_recherchenumero.SelectedIndex;
                    break;

            }
        }

        private void btn_modifier_Click(object sender, EventArgs e)
        {
            
        }
    }
}
