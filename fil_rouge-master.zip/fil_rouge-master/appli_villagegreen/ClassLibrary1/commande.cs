﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Commande
{
    public class Class1
    {
        //on défini les méthodes des paramètres qui sont nécessaires mais on ne les codes pas
        public int id { get; set; }
        public string etat { get; set; }
        public int paiement { get; set; }
        public int date { get; set; }
        public int total { get; set; }
        public int datepaiement { get; set; }
            
    }
}
