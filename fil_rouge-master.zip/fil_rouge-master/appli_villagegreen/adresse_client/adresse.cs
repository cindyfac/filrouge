﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adresse
{
    public class Class1
    {
        public int id { get; set; }
        public string nom_adresse { get; set; }
        public string adresse { get; set; }
        public string ville { get; set; }
        public int codepostal { get; set; }
        public string mail { get; set; }
        public int telephone { get; set; }

    }
}
